<?php

include("../includes/connect.php");

	if( isset($_POST['submit']) ){
		$selectedSource = $_POST['sourceCity'];
		$selectedDestination = $_POST['destinationCity'];
		$selectedDate = $_POST['journey'];
		$selectedRide = $_POST['ride'];
		
		echo $selectedRide ;
		echo "<br /> ";
		echo $selectedSource ;
		echo "<br /> ";
		echo $selectedDestination; 
		echo "<br /> ";
		echo $selectedDate; 

		
		/* open */
			
			// Check connection
			if (!$conn) {
				die("Connection failed: " . mysqli_connect_error());
			}
			

			$sql = "SELECT Trans_id , Source, Destination FROM transport_type where Arrival_Date = '" . $selectedDate ."'" ;
			echo $sql . "<br />";
			try{
				$result = mysqli_query($conn, $sql);
				
			}
			catch(Exception $ex){
				echo $ex;
			}

			if (mysqli_num_rows($result) > 0) {
				// output data of each row
				while($row = mysqli_fetch_assoc($result)) {
					echo "id: " . $row["Trans_id"]. " - Source: " . $row["Source"]. " " . $row["Destination"]. "<br>";
				}
			} else {
				echo "0 results";
			} 

			mysqli_close($conn);
		/* close  */
	}
?>

