<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"/>
<title>Result</title>
<link rel="stylesheet" type="text/css" href="css/reset.css" media="screen" />
<link rel="stylesheet" type="text/css" href="css/layout.css"  />
<link rel="stylesheet" type="text/css" href="css/menu.css"  />
<link rel="stylesheet" type="text/css" href="css/font-awesome.css" />
<link rel="stylesheet" type="text/css" href='http://fonts.googleapis.com/css?family=Leckerli+One'  />
<link rel="stylesheet" type="text/css" href='http://fonts.googleapis.com/css?family=Viga'  />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
<link rel="stylesheet" type="text/css" href="css/responsive.css"  />
<link rel="stylesheet" type="text/css" href="css/table.css"  />

</head>
<body>
<!--Fullscreen Image Start-->
<img id="full-screen-background-image" src="images/abstract-black-white-line-creative-creative-background-wallpaper.jpg" alt="img" />
<!--Fullscreen Image End-->

<!--Logo Start-->
<section id="logo">
	<a href="home.php"><h1>Let's Travel</h1></a>
    <h4>Make memories</h4>
</section>
<!--Logo End-->

<!--Menu Start-->
<nav class="menu nav_wrapper" id="myslidemenu">
    <ul class="menu" id="jqueryslidemenu">
        <li><a href="home.php"><i class="fa fa-home"></i>Home</a></li>
        <li><a href="aboutus.php">About</a>
        	<!--<ul class="sub-menu">
            	<li><a href="cpt.html">Team</a></li>
				<li><a href="cpt.html">mission</a></li>
                <li><a href="tabularfoodmenu.html">Vission</a></li>
            </ul>-->
        </li>
        <li><a href="contact.php"><i class="fa fa-phone-square"></i>Contact</a></li>
		<li><a href="Signin.php"><i class="fa fa-cutlery"></i>Account</a>
        	<ul class="sub-menu">
				<li><a href="signup.php">sign up</a></li>
            	<li><a href="signin.php">Sign in</a></li>
            </ul>
        </li>
		<li><a href="../urdu/home.php"><i class="fa fa-home"></i>اردو</a></li>
    </ul>
</nav>
<!--Menu End-->

<!--Container Start-->
   <section  id="container-fluid">
 <!--form start..-->
  <div  id="container" class="contact">
   <div  class="fullwidth">
   <table>
  <tr>
						<th>
							<font size="3"><strong>
							S.No &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp
							</strong>
						</th>
						<th>
						<font size="3"><strong>
							Source &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp
						
						</strong>
						</th>
						<th>
						<font size="3"><strong>
							Destination &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp
						</strong>

						</th>
						<th>
						<font size="3"><strong>
							Ride Type &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp
						</strong>

						</th>
						<th>
						<font size="3"><strong>
							Start_Time &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp
						</strong>

						</th>
						<th>
						<font size="3"><strong>
							End_Time &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp
						</strong>

						</th>
						<th>
						<font size="3"><strong>
							Start_Date &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp
						</strong>

						</th>
						<th>
						<font size="3"><strong>
							End_Date &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp
						</strong>

						</th>
						<th>
						<font size="3"><strong>
							Ticket Price &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp
						</strong>

						</th>
						<th>
						<font size="3"><strong>
							hops delay &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp
						</strong>

						</th>
					</tr>					
					
					<tbody>
				<?php

					include("../includes/connect.php");
					if( isset($_POST['submit']) ){
						// Check connection
						if (!$conn) {
							die("Connection failed: " . mysqli_connect_error());
						}
						else{
							$selectedSource = $_POST['sourceCity'];
							$selectedDestination = $_POST['destinationCity'];
							$selectedDate = $_POST['journey'];
							$selectedRide = "";
							if(!empty($_POST['ride'])){
								$selectedRide = $_POST['ride'];
							}
							if($selectedRide == "all"){
								
								//$selectedRide = " AND Journey_type = '" . $selectedRide . "'";
								getFlights($selectedDestination, $selectedSource, $selectedDate, "Flight");
								getTrains($selectedDestination, $selectedSource, $selectedDate, "Train");
								getBus($selectedDestination, $selectedSource, $selectedDate, "Bus");
							}
							else{
								if(!empty($_POST['check_list'])){
								// Loop to store and display values of individual checked checkbox.
									foreach($_POST['check_list'] as $selected){
										if($selected == "Flight" ){
											getFlights($selectedDestination, $selectedSource, $selectedDate, "Flight");
										}
										else if($selected == "Train"){
											getTrains($selectedDestination, $selectedSource, $selectedDate, "Train");
										}
										else if($selected == "Bus" ){
											getBus($selectedDestination, $selectedSource, $selectedDate, "Bus");
										}
										//echo $selected."</br>";
									}
								}
							}
							
							
							/* echo $selectedRide ;
							echo "<br /> ";
							echo $selectedSource ;
							echo "<br /> ";
							echo $selectedDestination; 
							echo "<br /> ";
							echo $selectedDate;  */
							//echo $selectedRide;
							
							
						}
						
					}
					
				?>
				<?php
					function getFlights($selectedDestination, $selectedSource, $selectedDate, $selectedRide){
						$selectedRide = " AND Journey_type = '" . $selectedRide . "'";
						include("../includes/connect.php");
						$sql = "SELECT Trans_id , Source, Destination, Journey_type,Start_Date, End_Date, Start_Time, End_Time FROM transport_type where destination = '" . $selectedDestination .  "' AND source = '" . $selectedSource .  "' AND Start_Date = '" . $selectedDate ."'" . $selectedRide ;
							
						$result = mysqli_query($conn, $sql);
								
						if (mysqli_num_rows($result) > 0) {
								// output data of each row
								$i = 1;
							while($row = mysqli_fetch_assoc($result)) {
								
								echo "<tr class='active'> <td> " . $i . " </td> <td> " . $row["Source"]. " </td> <td> " . $row["Destination"]. " </td><td> ". $row["Journey_type"]." </td> <td> ". $row["Start_Time"]." </td><td> ". $row["End_Time"]." </td><td> ". $row["Start_Date"]." </td><td> ". $row["End_Date"]." </td></tr> ";
								$i++;
							}
						} else {
							echo "<tr><td> No flight Available </td></tr>";
						} 
						mysqli_close($conn);	
					}
					
					function getTrains($selectedDestination, $selectedSource, $selectedDate, $selectedRide){
						$selectedRide = " AND Journey_type = '" . $selectedRide . "'";
						include("../includes/connect.php");
						$sql = "SELECT Trans_id , Source, Destination, Journey_type,Start_Date, End_Date, Start_Time, End_Time FROM transport_type where destination = '" . $selectedDestination .  "' AND source = '" . $selectedSource .  "' AND Start_Date = '" . $selectedDate ."'" . $selectedRide ;
							
						$result = mysqli_query($conn, $sql);
								
						if (mysqli_num_rows($result) > 0) {
								// output data of each row
								$i = 1;
							while($row = mysqli_fetch_assoc($result)) {
								echo "<tr class='success'> <td> " . $i . " </td> <td> " . $row["Source"]. " </td> <td> " . $row["Destination"]. " </td><td> ". $row["Journey_type"]." </td> <td> ". $row["Start_Time"]." </td><td> ". $row["End_Time"]." </td><td> ". $row["Start_Date"]." </td><td> ". $row["End_Date"]." </td></tr> ";
								$i++;
							}
						} else {
							echo "<tr><td> No Ride Available for train</td></tr>";
						} 
						mysqli_close($conn);	
					}
					
					function getBus($selectedDestination, $selectedSource, $selectedDate, $selectedRide){
						$selectedRide = " AND Journey_type = '" . $selectedRide . "'";
						include("../includes/connect.php");
						$sql = "SELECT Trans_id , Source, Destination, Journey_type ,Start_Date, End_Date, Start_Time, End_Time FROM transport_type where destination = '" . $selectedDestination .  "' AND source = '" . $selectedSource .  "' AND Start_Date = '" . $selectedDate ."'" . $selectedRide ;
							
						$result = mysqli_query($conn, $sql);
								
						if (mysqli_num_rows($result) > 0) {
								// output data of each row
								$i = 1;
							while($row = mysqli_fetch_assoc($result)) {
								echo "<tr class='warning'> <td> " . $i. " </td> <td> " . $row["Source"]. " </td> <td> " . $row["Destination"]. " </td><td> ". $row["Journey_type"]." </td> <td> ". $row["Start_Time"]." </td><td> ". $row["End_Time"]." </td><td> ". $row["Start_Date"]." </td><td> ". $row["End_Date"]." </td></tr> ";
								$i++;
							}
						} else {
							echo "<tr><td> No Ride Available for bus</td></tr>";
						} 
						mysqli_close($conn);	
					}
				?>
					
					
					
				</tbody>
					
					
</table>
   
 </div>
<!--form end..-->

  <!--sidebar  start..-->

<!--sidebar End-->
</div>
 </section>
<!--Container End-->

<!--Footer Start-->
<footer>
	<div class="one-third">
    	<p>	</p>
    </div>
    <div class="one-third">
    	<p class="copy-right"> All Rights Reserved by CS@DSU</p>
    </div>
    <div class="one-third-last">
    	<ul>
        	<li><i class="fa fa-twitter"></i></li>
            <li><i class="fa fa-facebook"></i></li>
            <li><i class="fa fa-rss"></i></li>
            <li><i class="fa fa-youtube"></i></li>
            <li><i class="fa fa-linkedin"></i></li>
        </ul>
    </div>   
</footer>
<!--Footer End-->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/contact.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
</body>
</html>
