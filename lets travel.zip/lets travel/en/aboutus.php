<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"/>
<title>Contact Us</title>
<link rel="stylesheet" type="text/css" href="css/reset.css" media="screen" />
<link rel="stylesheet" type="text/css" href="css/layout.css"  />
<link rel="stylesheet" type="text/css" href="css/menu.css"  />
<link rel="stylesheet" type="text/css" href="css/font-awesome.css" />
<link rel="stylesheet" type="text/css" href='http://fonts.googleapis.com/css?family=Leckerli+One'  />
<link rel="stylesheet" type="text/css" href='http://fonts.googleapis.com/css?family=Viga'  />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
<link rel="stylesheet" type="text/css" href="css/responsive.css"  />
</head>
<body>
<!--Fullscreen Image Start-->
<img id="full-screen-background-image" src="images/abstract-black-white-line-creative-creative-background-wallpaper.jpg" alt="img" />
<!--Fullscreen Image End-->

<!--Logo Start-->
<section id="logo">
	<a href="home.php"><h1>Let's Travel</h1></a>
    <h4>Make memories</h4>
</section>
<!--Logo End-->

<!--Menu Start-->
<nav class="menu nav_wrapper" id="myslidemenu">
    <ul class="menu" id="jqueryslidemenu">
        <li><a href="home.php"><i class="fa fa-home"></i>Home</a></li>
        <li><a href="aboutus.php">About Us</a>
        	<!--<ul class="sub-menu">
            	<li><a href="cpt.html">Team</a></li>
				<li><a href="cpt.html">mission</a></li>
                <li><a href="tabularfoodmenu.html">Vission</a></li>
            </ul>-->
        </li>
        <li><a href="contact.php"><i class="fa fa-phone-square"></i>Contact</a></li>
		<li><a href="signin.php"><i class="fa fa-cutlery"></i>Account</a>
        	<ul class="sub-menu">
				<li><a href="signin.php">sign in</a></li>
            	<li><a href="signup.php">Sign up</a></li>
            </ul>
        </li>
		<li><a href="../urdu/home.php"><i class="fa fa-home"></i>اردو</a></li>
    </ul>
</nav>
<!--Menu End-->

<!--Container Start-->
   <section  id="container-fluid">
 <!--form start..-->
  <div  id="container" class="contact">
   <div  class="two-third">
   <div class="google_map">
   <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3621.4398725227597!2d67.07774001500184!3d24.81462658407559!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x4e41a2d7dd487cfc!2sDHA+Suffa+University!5e0!3m2!1sen!2s!4v1506646363114" width="600" height="450" frameborder="0" style="border:0"></iframe>
</div>
   
      <div class="contact_form">
            
            <form id="contact-form" name="contact-form" action="sendEmail.php" method="post">
            <div id="main">
            <div id="contact_response">
            <div class="success">    </div>
            </div>
            <div class="one-third"><input type="text" placeholder="Name" size="23" id="name" name="name"></div>
            <div class="one-third"><input type="text" size="23" id="email" placeholder="Email" name="email"></div>
            <div class="one-third-last"><input type="text" size="23" id="subject" placeholder="Subject" name="subject"></div>
            <div class="fullwidth">
            <textarea placeholder="Your Message" rows="4" cols="30" id="message" name="message"></textarea>
            </div>
            <div class="clear"></div>
            <div>
            <input type="submit" value="Submit" id="contact_submit" name="contact_submit" class="readmore readmore-1 readmore-1a">
            <input type="reset" value="Clear" id="reset" name="reset" class="readmore readmore-1 readmore-1a">
            </div>
            </div>
            </form>
        </div> 
 </div>
<!--form end..-->

  <!--sidebar  start..-->
<aside class="one-third-last">
<div class="sidebar">
    <div class="address"><i class="fa fa-home"> </i></div>
    <div class="description">
        <a href="#"><h3>Address</h3></a>
        <p>Dha phase 7 ext.<span> Khayaban e tufail</span><br />
        Karachi, Pakistan<br />
        IL 0213-1234567 </p>
    </div>
</div>
<div class="sidebar"> 
    <div class="address"><i class="fa fa-phone"> </i></div>
    <div class="description">
        <a href="#"><h3>Quick Contact</h3></a>
        <p>03312806369<br />
        +212 2512 58458 256<br />
        +3231 21425<br />
        </p>
    </div>
</div>

<div class="sidebar"> 
    <div class="address"><i class="fa fa-envelope"> </i></div>
    <div class="description">
        <a href="#"><h3>Email Us</h3></a>
        <p>tehmi.khalid.tk@gmail.com<br />
        tahasiddiqui@gmail.com<br />
        <br />
        </p>
    </div>
</div>

<!--sidebar End-->
</div>
 </section>
<!--Container End-->

<!--Footer Start-->
<footer>
	<div class="one-third">
    	<p>	</p>
    </div>
    <div class="one-third">
    	<p class="copy-right"> All Rights Reserved by CS@DSU</p>
    </div>
    <div class="one-third-last">
    	<ul>
        	<li><i class="fa fa-twitter"></i></li>
            <li><i class="fa fa-facebook"></i></li>
            <li><i class="fa fa-rss"></i></li>
            <li><i class="fa fa-youtube"></i></li>
            <li><i class="fa fa-linkedin"></i></li>
        </ul>
    </div>   
</footer>
<!--Footer End-->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/contact.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
</body>
</html>
